﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace vt2026_a3
{
    internal class SaveManager
    {
        //singelto  ↓↓↓↓
        private static SaveManager? instance;
        private SaveManager(TextBox inputfeild, ToolStripMenuItem aniTsmi)
        {
            this.inputfeild = inputfeild;
            this.aniTsmi = aniTsmi;
            this.FilenameIn("");
            this.altered = false;
            this.initialText = inputfeild.Text;
        }
        static internal SaveManager getInstance(TextBox inputfeild, ToolStripMenuItem aniTsmi) { return instance ?? (instance = new(inputfeild, aniTsmi)); }
        //singelton ↑↑↑↑ wasnt rly neede since this is just called once when creating the form but yeah 

        private const string defaultname = "newfile.txt";
        private TextBox inputfeild;
        private string? initialText;
        private string? filename;
        private bool altered;

        private ToolStripMenuItem aniTsmi;//animation stuff below
        private System.Windows.Forms.Timer? timer;
        private byte aniStep;
        private int maxLine;
        private int currentLine;
        private string[]? framelines;

        //properties
        internal bool Altered { get { return altered; }set { altered = value; } }
        internal string Filename { get { return (filename == string.Empty) || (filename == null) ? defaultname : filename; } }
        internal void FilenameIn(string value) { filename = value; Animationcheck(value); } // setter (not property)

        /// <summary>
        /// pre: true
        /// post: saves and stuff 
        /// (pretty short just look at the code, using words will take longer to understand)
        /// </summary>
        internal bool Save()
        {
            if (filename == "" || filename == null || filename == string.Empty) { return SaveAs(); }
            if (!altered) { return true; }
            using (StreamWriter writer = new(filename))
            {
                writer.Write(inputfeild.Text);
            }
            initialText = inputfeild.Text;
            altered = false;
            return true;
        }
        /// <summary>
        /// pre: permission by os to write files
        /// post: allows user to save files with specified location and name 
        /// currently an issue with the name including the file path, will work on it later
        /// </summary>
        internal bool SaveAs()
        {
            SaveFileDialog saveFileDialog = new()
            {
                InitialDirectory = Application.StartupPath,
                //InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments),
                Filter = "txt files (*.txt)|*.txt",
                AddToRecent = true,
                FileName = Filename
            };
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {//try catch for safety and unknown risks abt file streaming, how this all is done is inspired by a previous project i have worked on
                    using (StreamWriter writer = new(saveFileDialog.FileName))
                    {
                        writer.Write(inputfeild.Text);
                    }
                    initialText = inputfeild.Text;
                    altered = false;
                    FilenameIn(saveFileDialog.FileName);

                }
                catch (Exception) { }
                return true;
            }
            return false;
        }
        /// <summary>
        /// pre: permission by os to read files
        /// post: loads a textfile if one is selected by user
        /// </summary>
        internal void Loadf()
        {
            OpenFileDialog openFileDialog = new()
            {

                InitialDirectory = Application.StartupPath,
                //InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.CommonDocuments),
                Filter = "txt files (*.txt)|*.txt",
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                inputfeild.Text = Loadf(openFileDialog.FileName);
                FilenameIn(openFileDialog.FileName);
                altered = false;

            }
        }
        /// <summary>
        /// ftches contents of file as a string
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        internal string Loadf(String path)
        {

            if (timer != null && timer.Enabled) { timer.Dispose(); }
            try
            {//try catch just in case idk file reading can be quirky and im not too familiar
                string text;
                using (StreamReader reader = new(path))
                {
                    //inputfeild.Text = reader.ReadLine();
                    text = reader.ReadToEnd();//self explantory
                }
                DocStats.FixNewLine(ref text);
                initialText = inputfeild.Text;
                return text;
            }
            catch (Exception) { return "[load error]"; }
        }
        /// <summary>
        /// pre: true
        /// post: makes a new yk thingy blank page
        /// </summary>
        internal void New()
        {

            if (timer != null && timer.Enabled) { timer.Dispose(); }
            inputfeild.Text = "";
            initialText = inputfeild.Text;
            FilenameIn(defaultname);
            altered = false;
        }
        /// <summary>
        /// pre: title!=null
        /// post: title and altered updated, asterisk added if changed since last save, removed if not 
        /// </summary>
        /// <param name="title"></param>
        internal void Titleasterisk(Form frm)
        {
            string name = Filename.Substring(Math.Max(Filename.LastIndexOf('\\') + 1, 0)); //filename is stored as the full path, here i take whats after the last \ , only for display 
            switch (inputfeild.Text == initialText)
            {
                case true: altered = false; frm.Text = name; break;
                case false: altered = true; frm.Text = "*" + name; break;
            }
        }

        //everything below has to do with animation (reminder accessable by adding "-animation-XX" to ur title where X is a number 0-9)


        /// <summary>
        /// pre: true
        /// post: checks if loded file is made to be an animation if so sets animation to true, enebales the animiation tab, sets animation step and max line
        /// </summary>
        /// <param name="filename"></param>
        private void Animationcheck(string filename)
        {
            aniTsmi.Enabled = false;
            if (filename.Length < 12) { return; }
            if (filename.Contains("-animation-"))
            {
                //if (byte.TryParse(filename.Substring(filename.LastIndexOf("-animation-") + 11, 2), out aniStep))
                if (byte.TryParse(filename.AsSpan(filename.LastIndexOf("-animation-") + 11, 2), out aniStep))
                {
                    aniTsmi.Enabled = true;
                    maxLine = DocStats.LineCount(inputfeild.Text);

                }

            }
        }
        /// <summary>
        /// pre: animation==true && aniStep!=(null || <=0) && filename!= invalid
        /// post: displays lines from file as "frames" taking the aniStep variable as an indicator for how many lines are allocated for each frame
        /// some notes, the number after the "-animation-" must be two chars, say 5 would be 05 17 would be 17 ect ect, and this number
        /// represents the number of lines per frame. each line is defined by the line break char \n or enviroment.newline. 
        /// the first line of the file is reserved for comments and or refrenes to where it came from if that is needed.
        /// at lower animation speeds this could be used as an outo scroll, however the timer doesnt care abt what the actuall content being displayed
        /// looks like so it ould be wayy to little time or way too much and it can be hard to tell befroehand 
        /// </summary>
        internal void AnimateStart(bool frmCount, uint mspf)
        {
            altered = true;
            if (filename == null) { return; }
            if (timer != null && timer.Enabled) { timer.Stop(); timer.Dispose(); }
            currentLine = 0;

            framelines = File.ReadAllLines(filename);//https://stackoverflow.com/questions/20287479/reading-a-specific-line-with-streamreader

            timer = new();
            timer.Interval = (int)Math.Clamp(mspf, 1, int.MaxValue);
            timer.Tick += new EventHandler((Object? o, EventArgs e) =>
            {
                if (aniStep <= 0) { timer.Stop(); timer.Dispose(); return; }
                if (currentLine == maxLine) { timer.Stop(); timer.Dispose(); return; }

                inputfeild.Text = "";
                for (int i = 0; i < aniStep; i++)
                {
                    if (currentLine++ == maxLine - 1) { break; }
                    //text = File.ReadLines(filename).Skip(currentLine).FirstOrDefault() ?? "";/*https://stackoverflow.com/questions/20287479/reading-a-specific-line-with-streamreader*/
                    inputfeild.Text += framelines[currentLine] + Environment.NewLine;
                }
                if (frmCount)
                    inputfeild.Text += "  (" + currentLine / aniStep + "/" + maxLine / aniStep + ")";

            });
            timer.Start();
        }
        /// <summary>
        /// pre: true
        /// post: swaps  the enebaled attribute of the timer (for animation) and returns true if the timer like is a think atm and false if its null 
        /// </summary>
        /// <returns></returns>
        internal bool AnimationStartStop()
        {
            if (timer == null) { return false; } //for warning suppresion, the line under does everything this dose so its redundant in all but dev enviroment
            if (AnimationEndCheck()) { return false; }
            switch (timer.Enabled)
            {
                case true: timer.Enabled = false; ; break;
                case false: timer.Enabled = true; ; break;
            }
            return true;
        }
        /// <summary>
        /// pre: true
        /// post: checks if the timer doesnt exists or if animation is compleated and returns true in either of those cases otherwise false 
        /// </summary>
        /// <returns></returns>
        internal bool AnimationEndCheck() { return (timer == null) || (currentLine >= maxLine-2); }

    }
}
