﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vt2026_a3
{/// <summary>
///  
/// 
/// absolutly nothing in here should need to be commeneted
/// everything should be super intuative annd simple
/// i even made the entire class static how much more uncomplex can it get if im able to do that
/// 
/// </summary>
    internal static class DocStats
    {

        internal static int SymbolCount(string s) { return s.Count<char>(); }
        internal static int NonWhitspaceCount(string s) { return s.Count<char>() - s.Count<char>(char.IsWhiteSpace); }
        internal static int WordCount(string s)
        {
            int output = 0;
            bool prevwhitspace = true;
            for (int i = 0; i < s.Length; i++)
            {
                if (char.IsWhiteSpace(s[i])) { prevwhitspace = true; }
                if (!char.IsWhiteSpace(s[i]) &&prevwhitspace)
                {
                    output++;
                    prevwhitspace = false;
                }
            }
            return output;
        }
        internal static int LineCount(string s) { return s.Count<char>(isNewline); }
        private static bool isNewline(char c) { return (c == '\n')||(c.ToString()==Environment.NewLine); }
        internal static void FixNewLine(ref string s) { s=s.Replace("\n", Environment.NewLine);}
    }
}
