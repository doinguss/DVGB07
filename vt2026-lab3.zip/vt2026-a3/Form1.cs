
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace vt2026_a3
{
    public partial class Form1 : Form
    {
        private SaveManager SM;
        private bool lazyskipp; //special bypass that the animation uses to avoid most of the computationally heavy steps when changing text
        private bool frmCount; //for animation
        private uint mspf; // for aniamtion

        public Form1()
        {
            InitializeComponent();
            SM = SaveManager.getInstance(txtfeildTxb, aniTsmi);
            this.Text = SM.Filename;
            this.lazyskipp = false;
            mspf = 30; //set to 30cuz thats the correct timing for the inccluded animation tesst file
            frmCount = true;
            aniTsmi.Enabled = false;
            pauseTsmi.Enabled = false;

        }
        /// <summary>
        /// pre: true
        /// post: updates document metrics (are not stored anywhere except the visual element) and does thee title assterisk check
        /// </summary>
        /// <returns></returns>
        private bool txtchangeCheck()
        {
            try
            {
                SM.Titleasterisk(this);
            }
            catch (Exception e) { Debug.WriteLine("cannot access 'titleasterisk' from sm (savemanager)"); Debug.WriteLine(e); }
            try
            {
                charTssl.Text = "characters: " + DocStats.SymbolCount(txtfeildTxb.Text);
                exCharTssl.Text = "(excl whitespace): " + DocStats.NonWhitspaceCount(txtfeildTxb.Text);
                wordsTssl.Text = "words: " + DocStats.WordCount(txtfeildTxb.Text);
                linesTssl.Text = "lines: " + DocStats.LineCount(txtfeildTxb.Text);
            }
            catch (Exception) { Debug.WriteLine("cannot access docstats"); }
            return true;
        }
        /// <summary>
        /// pre: true
        /// post: textchange if !lazyskipp
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (lazyskipp) { return; }

            txtchangeCheck();
        }
        /// <summary>
        /// pre: true
        /// post: handels keyboardinputs used for comand keys like ctrl + s 
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.S | Keys.Control: saveTsmi.PerformClick(); return true;
                case Keys.W | Keys.Control: saveAsTsmi.PerformClick(); return true;
                case Keys.L | Keys.Control: loadTsmi.PerformClick(); return true;
                case Keys.N | Keys.Control: newTsmi.PerformClick(); return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        /// <summary>
        /// pre:true
        /// post: closes conditionally
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitTsmi_Click(object sender, EventArgs e)
        {
            progrssloss(this.Close);
        }
        /// <summary>
        /// pre: true
        /// post: writes ontents of textbox to file, askes for filelocation if non already given 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveTsmi_Click(object sender, EventArgs e)
        {
            try
            {
                SM.Save();
                txtchangeCheck();
                lazyskipp = false;
            }
            catch (Exception) { Debug.WriteLine("cannot access savemanger (save, titleasterisk)"); }

        }
        /// <summary>
        /// pre: true
        /// post: saves to specified locaation 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void saveAsTsmi_Click(object sender, EventArgs e)
        {
            try
            {
                SM.SaveAs();
                txtchangeCheck();
                lazyskipp = false;
            }
            catch (Exception) { Debug.WriteLine("cannot access savemanger (saveas, titleasterisk)"); }
        }
        /// <summary>
        /// pre: true
        /// post loads conditionally from specified location (has filter for text files but can handel anything except an iso file)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void loadTsmi_Click(object sender, EventArgs e)
        {
            progrssloss(SM.Loadf);
            lazyskipp = false;
        }
        /// <summary>
        /// pre: true
        /// post: clears all conditionally (the new empty file  isnt saved to long term memmory by defauly its fast as the user saves that itll be assigned a location thtough the saveas path)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newTsmi_Click(object sender, EventArgs e)
        {
            progrssloss(SM.New);
            lazyskipp = false;

        }
        /// <summary>
        /// pre: true (used when changes have happened that would be deleted if action is taken)
        /// post: popup asks if to proceed without saving, yes proceeds, no proceeds and saves, cancel does nothing 
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private bool progrssloss(Action p)
        {
            try
            {
                if (!SM.Altered) { p(); txtchangeCheck(); return true; }
                switch (MessageBox.Show("proceed without saving?", "save?", MessageBoxButtons.YesNoCancel))
                {
                    case DialogResult.Yes: p(); txtchangeCheck(); return true;
                    case DialogResult.No: bool o = SM.Save(); p(); txtchangeCheck(); return o;
                    case DialogResult.Cancel: txtchangeCheck(); return false;
                }
            }
            catch (Exception e) { Debug.WriteLine(e); }
            return false;
        }
        /// <summary>
        /// as above but without any callback funtion
        /// </summary>
        /// <returns></returns>
        private bool progrssloss()
        {
            try
            {
                if (!SM.Altered) { txtchangeCheck(); return true; }
                switch (MessageBox.Show("proceed without saving?", "save?", MessageBoxButtons.YesNoCancel))
                {
                    case DialogResult.Yes: txtchangeCheck(); return true;
                    case DialogResult.No: return SM.Save() && txtchangeCheck();
                    case DialogResult.Cancel: txtchangeCheck(); return false;
                }
            }
            catch (Exception e) { Debug.WriteLine(e); }
            return false;
        }
        /// <summary>
        /// pre: true
        /// post: interupts form closing conditionally
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = !progrssloss(); //https://stackoverflow.com/questions/55887874/how-to-stop-windows-form-from-closing-but-hide-upon-clicking-the-x
        }


        /// <summary>
        /// pre: file draged over
        /// post: sets the effect of the drag event bassed off of drag data type as well as keyboard input
        /// took a lot of inspiration from the documentation on this one im not really sure how these if conditions compute myself
        /// documentation linked below. i hijacked the link effect tho for the shift control. noarmally shift would just move it 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtfeildTxb_DragOver(object sender, DragEventArgs e)
        {//(https://learn.microsoft.com/en-us/dotnet/api/system.windows.forms.control.dragover?view=windowsdesktop-10.0) 
            if (e.Data == null) { return; }
            if (!e.Data.GetDataPresent(DataFormats.FileDrop, false))
            {
                e.Effect = DragDropEffects.None;
                return;
            }
            //if ((e.KeyState & (8 + 32)) == (8 + 32) && (e.AllowedEffect & DragDropEffects.Link) == DragDropEffects.Link)
            //{//alt+ctrl
            //    e.Effect = DragDropEffects.Link;
            //}
            //else if ((e.KeyState & (32)) == (32) && (e.AllowedEffect & DragDropEffects.Link) == DragDropEffects.Link)
            //{//alt
            //    e.Effect = DragDropEffects.Link;
            //}
            else if ((e.KeyState & (4)) == (4) && (e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
            {//shift
                //e.Effect = DragDropEffects.Move;
                e.Effect = DragDropEffects.Link;
            }
            else if ((e.KeyState & (8)) == (8) && (e.AllowedEffect & DragDropEffects.Copy) == DragDropEffects.Copy)
            {//ctrl
                e.Effect = DragDropEffects.Copy;
            }
            else if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
            {
                e.Effect = DragDropEffects.Move;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }
        /// <summary>
        /// pre: drag event accepted
        /// post: tries to do the thing specified in yk
        /// took inspo from this form post abt how to read from fragged file, mainly the e.data.getdata(dataformats.filedrop) was hard to figure out
        /// but also that it should be a string array 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtfeildTxb_DragDrop(object sender, DragEventArgs e)
        { //https://stackoverflow.com/questions/9464001/drag-and-drop-file-into-textbox
            try
            {
                if (e.Data == null) { return; }
                string[]? files = (string[]?)e.Data.GetData(DataFormats.FileDrop);
                if (files == null || files.Length == 0 || files[0] == null) { return; }
                switch (e.Effect)
                {
                    case DragDropEffects.Move:
                        progrssloss(() =>
                        {
                            txtfeildTxb.Text = SM.Loadf(files[0]);
                            SM.Altered = false;
                            SM.FilenameIn(files[0]);
                        });
                        break;
                    case DragDropEffects.Copy:
                        txtfeildTxb.Text += SM.Loadf(files[0]);
                        break;
                    case DragDropEffects.Link:
                        txtfeildTxb.Paste(SM.Loadf(files[0]));
                        break;
                }
            }
            catch { Debug.WriteLine("bad"); }

        }
        /// <summary>
        /// pre: true
        /// post: validates entering of drag event
        /// �not sure if this is needed i saw someone on this form thread talking abt WPF which this is not, but i thought id try that as well. 
        /// the problem wasnt with this tho it was that i usded AllowedEffet in the switch caase in th� method above absentmindedly.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtfeildTxb_DragEnter(object sender, DragEventArgs e)
        { //https://stackoverflow.com/questions/9464001/drag-and-drop-file-into-textbox
            e.Effect = DragDropEffects.Copy;
        }



        /// <summary>
        /// pre: sm.animationcheck passed (=> anistep assigned and play animation tsmi enabled) 
        /// post: plays animation yay :D then leaves it on last frame, also ativates a bypass to avoid unneccessary calculations and checks
        /// the names residual from eralier drafts
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void playToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lazyskipp = true;
            SM.AnimateStart(frmCount, mspf);
        }
        /// <summary>
        /// pre: animation textfile
        /// post: allows play if validation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fpmsTstb_TextChanged(object sender, EventArgs e)
        {
            ValidateAnimaationParam();
        }
        /// <summary>
        /// pre: animation textfile
        /// post: allows play if validation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void frmcountTstb_TextChanged(object sender, EventArgs e)
        {
            ValidateAnimaationParam();
        }
        /// <summary>
        /// pre: animation text file
        /// post:allowss play if conditions below are met without early termination
        /// </summary>
        private void ValidateAnimaationParam()
        {

            playTsmi.Enabled = false;
            switch (frmcountTstb.Text.Trim())
            {
                case "y":
                case "Y":
                case "yes":
                case "Yes":
                case "YES":
                case "true":
                case "True":
                case "TRUE": frmCount = true; break;
                case "n":
                case "N":
                case "no":
                case "No":
                case "NO":
                case "false":
                case "False":
                case "FALSE": frmCount = false; break;
                default: return;
            }
            if (!uint.TryParse(fpmsTstb.Text.Trim(), out mspf)) { return; }
            if (mspf == 0) { return; }
            playTsmi.Enabled = true;
        }
        /// <summary>
        /// pre: animation textfile
        /// post: pause sor resumes the animation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pauseTsmi_Click(object sender, EventArgs e)
        {
            pauseTsmi.Enabled = SM.AnimationStartStop();
        }
        /// <summary>
        /// pre: animation textfile
        /// post: shows or hides the pause continue button as appropriate 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void aniTsmi_Click(object sender, EventArgs e)
        {
            pauseTsmi.Enabled = !SM.AnimationEndCheck();
        }
    }
}
